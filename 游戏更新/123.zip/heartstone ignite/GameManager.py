import time
import pygame
import sys
from Settings import *
from Button import *
from Brick import *
from Map import *
from UserCharacter import *
from move_fuc import *

class GameManager:
    def __init__(self):
        
        self.screen = pygame.display.set_mode((ScreenSetting.screen_width, ScreenSetting.screen_height))
        self.background_layer = pygame.Surface((ScreenSetting.screen_width, ScreenSetting.screen_height))
        pygame.display.set_caption(ScreenSetting.title)
        self.state=GameState.MAIN_INTERGACE
        self.user=UserCharacter()
        self.mmap=Maps.list[0]
        self.user.pos_x=5
        self.user.pos_y=2
        

    def main_code(self):
        if self.state == GameState.INIT:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.state=GameState.EXIT
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.state=GameState.EXIT
                        return
                 
        elif self.state== GameState.MAIN_INTERGACE:
            self.background_layer.fill((255, 255, 255))  # Clear the background layer
            self.screen.blit(self.background_layer, (0, 0))
            mouse_pos = pygame.mouse.get_pos()
            flag=Mainintergace.Start_button.draw_button(mouse_pos,self.screen)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.state=GameState.EXIT
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.state=GameState.EXIT
                        return

                if flag and event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        self.state=GameState.PLAY
                        return
                pygame.display.flip()
        
        elif self.state== GameState.EXIT:
            pygame.quit()
            sys.exit()
        elif self.state==GameState.PLAY:
            layer_top,layer_left,user_top,user_left=self.mmap.calc_topleft(self.user)
            self.screen.blit(self.mmap.map_image_layer,(layer_left,layer_top))
            
            self.screen.blit(self.user.layer,(user_top,user_left))
            self.user.inventory.draw_inventory(self.user.item_number,self.screen)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.state=GameState.EXIT
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.state=GameState.EXIT
                        return
                    
                if event.type== pygame.KEYDOWN:
                    player_move=-1
                    if event.key==pygame.K_w:
                        player_move=0
                    elif event.key==pygame.K_a:
                        player_move=1
                    elif event.key==pygame.K_s:
                        player_move=2
                    elif event.key==pygame.K_d:
                        player_move=3
                    elif event.key==pygame.K_1:
                        if(self.user.item_number==0):
                            self.user.item_number=-1
                        else:
                            self.user.item_number=0
                        self.user.last_item_number=0
                        player_move=4
                    elif event.key==pygame.K_2:
                        if(self.user.item_number==1):
                            self.user.item_number=-1
                        else:
                            self.user.item_number=1
                        self.user.last_item_number=1
                        player_move=4
                    elif event.key==pygame.K_3:
                        if(self.user.item_number==2):
                            self.user.item_number=-1
                        else:
                            self.user.item_number=2
                        self.user.last_item_number=2
                        player_move=4
                    elif event.key==pygame.K_q:
                        self.user.item_number=(self.user.last_item_number+2)%3
                        self.user.last_item_number=self.user.item_number
                        player_move=4
                    elif event.key==pygame.K_e:
                        self.user.item_number=(self.user.last_item_number+1)%3
                        self.user.last_item_number=self.user.item_number
                        player_move=4
                    elif event.key==pygame.K_r:
                        if(self.user.item_number!=-1):
                            self.user.rotate_item(self.user.item_number)
                    elif event.key==pygame.K_4:
                        print(4)
                    elif event.key==pygame.K_f:
                        self.user.laying_pos_x=self.user.pos_x
                        self.user.laying_pos_y=self.user.pos_y
#                        if self.user.item_number!=-1:
#                            if self.user.inventory.item[self.user.item_number].flag:
#                                self.user.laying_pos_x,self.user.laying_pos_y=laying_pos_init(self.user.pos_x,self.user.pos_y,self.user.inventory.item[self.user.item_number])
#                        self.state=GameState.LAYING
                
                    self.user.update_direction(player_move)
                    if move_legal(player_move,self.user,self.mmap)==1:
                        self.user.pos_x,self.user.pos_y=wasd_move(self.user.pos_x,self.user.pos_y,player_move)

    
            

    

        
