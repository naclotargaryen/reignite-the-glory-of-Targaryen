from Settings import *
from Brick import *
from Map import *

class Bricks:
     list=[]
     for i in range(BrickSetting.brick_number):
        list.append(Brick(i))
        
class Maps:
    list=[]
    for i in range(MapSetting.map_number):
         list.append(Map(i,Bricks.list))



