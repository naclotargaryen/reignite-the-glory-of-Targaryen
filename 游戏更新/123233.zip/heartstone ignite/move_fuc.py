from Settings import *


def wasd_move(pos_x,pos_y,move):
    if move==0:
        return pos_x,pos_y-1
    elif move==1:
        return pos_x-1,pos_y
    elif move==2:
        return pos_x,pos_y+1
    elif move==3:
        return pos_x+1,pos_y
    

def brick_legal(pos_x,pos_y,game_map):
    if(pos_x>=0 and pos_x<game_map.brick_number_cols and pos_y>=0 and pos_y<game_map.brick_number_rows):
        if BrickSetting.brick_movable[game_map.matrix[pos_y][pos_x]]:
            return 1
    return 0

def move_legal(move,user_character,game_map):
    if move==-1: return 0
    if move==0 or move==1 or move==2 or move==3:
        new_pos_x,new_pos_y=wasd_move(user_character.pos_x,user_character.pos_y,move)
        if(brick_legal(new_pos_x,new_pos_y,game_map)):
            return 1
    return 0

