from Settings import *
from Item import *

def laying_pos_calc(pos_x,pos_y,item,game_map):
    if(item.flag):
        if(pos_x+item.cols>game_map.brick_number_cols):
            pos_x=game_map.brick_number_cols-item.cols
        if(pos_y+item.rows>game_map.brick_number_rows):
            pos_y=game_map.brick_number_rows-item.rows
        if(pos_x<0):pos_x=0
        if(pos_y<0):pos_y=0
    return pos_x,pos_y
