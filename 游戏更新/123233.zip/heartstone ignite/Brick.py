

from Settings import *
class Brick:
    def __init__(self, brick_id):
        self.brick_id=brick_id
        self.loadimage=pygame.image.load(BrickSetting.brick_address_list[brick_id])
        self.image=pygame.transform.scale(self.loadimage,(BrickSetting.brick_len,BrickSetting.brick_len)) 



