import pygame
import sys
import time
from enum import Enum
import os


# Define all the MODE here 
class ControlMode(Enum):
    INIT_MODE = 0
    MAIN_INTERGACE_MODE = 1
    LOADING_MODE=2
    PLAY_MODE=3
    EXIT_MODE = 100

###################### All the variables are defined here #################
Mode = ControlMode.INIT_MODE  # When change the value of Mode, please use Mode=ControlMode.**_MODE
screen_width = 0
screen_height = 0
brick_len=0
title = ''
left_click = False
brick_address_list=[]
brick_list=[]
brick_number=0
current_file_dir=""
def varibles_init():
    global Mode, screen_width, screen_height, title,left_click,brick_len,brick_number,current_file_dir
    Mode = ControlMode.INIT_MODE
    screen_width = 800
    screen_height = 600
    title = "game"
    left_click = False
    brick_len=30
    brick_number=2
    current_file_dir = os.path.dirname(os.path.abspath(__file__))+"\\"

class Brick:
    def __init__(self, brick_id):
        self.brick_id=brick_id
        self.loadimage=pygame.image.load(current_file_dir+brick_address_list[brick_id])
        self.image=pygame.transform.scale(self.loadimage,(brick_len,brick_len))
        
def brick_address_list_init():
    global brick_address_list,brick_number
    for i in range(brick_number):
        brick_address_list.append(str(i)+".png")
        brick_list.append(Brick(i))
#    for i in range(2):
#       brick_address
##################### Some init #################
pygame.init()
varibles_init()
brick_address_list_init()
screen = pygame.display.set_mode((screen_width, screen_height))
background_layer = pygame.Surface((screen_width, screen_height))  # Background layer
pygame.display.set_caption(title)
Mode = ControlMode.MAIN_INTERGACE_MODE



# character_layer = pygame.Surface((800, 600), pygame.SRCALPHA)  # Character layer, supports transparency
# ui_layer = pygame.Surface((800, 600), pygame.SRCALPHA)


class Image:
    def __init__(self, address):
        self.address = address
        self.image = pygame.image.load(current_file_dir+address)
        self.image_width = self.image.get_width()
        self.image_height = self.image.get_height()

    def Draw_image(self, layer, x, y, need_width, need_height):
        layer.blit(pygame.transform.scale(self.image, (need_width, need_height)), (x, y))

    def Draw_image_MID(self, layer, x, y, need_width, need_height):
        layer.blit(pygame.transform.scale(self.image, (need_width, need_height)), (x - need_width / 2, y - need_height / 2))

class Character:
    def __init__(self, address,width,height):
        self.address=address
        self.width=width
        self.height=height
        self.load_image=pygame.image.load(current_file_dir+address)
        self.image=pygame.transform.scale(self.image,(width,height))
        
class Map:
    def __init__(self, address):
        self.address=address
        with open(self.address, "r") as file:
            self.brick_number_x, self.brick_number_y = map(int, file.readline().split())
            self.matrix=[list(map(int, line.split())) for line in file]
        self.total_width,self.total_height=self.brick_number_x*brick_len,self.brick_number_y*brick_len
        self.map_image_layer=pygame.Surface((self.total_width,self.total_height))
        for i in range(self.brick_number_x):
            for j in range(self.brick_number_y):
                self.map_image_layer.blit(brick_list[self.matrix[i][j]].image,(i*brick_len,j*brick_len))
        
# all the MODE should be defined as _**_MODE and have the following code
def _INIT_MODE():
    global Mode
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Mode = ControlMode.EXIT_MODE
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                Mode = ControlMode.EXIT_MODE
                return



def _MAIN_INTERGACE_MODE():
    global Mode
    background_layer.fill((255, 255, 255))  # Clear the background layer
    screen.blit(background_layer, (0, 0))
    Start_button = Image('start.png')
    start_width, start_height = screen_width / 4, screen_height / 4
    start_button_layer = pygame.Surface((start_width, start_height), pygame.SRCALPHA)
    Start_button.Draw_image(start_button_layer, 0, 0, start_width, start_height)
    start_width2, start_height2 = start_width / 5 * 6, start_height / 5 * 6
    start_button_layer2 = pygame.Surface((start_width2, start_height2), pygame.SRCALPHA)
    Start_button.Draw_image(start_button_layer2, 0, 0, start_width2, start_height2)
    

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Mode = ControlMode.EXIT_MODE
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                Mode = ControlMode.EXIT_MODE
                return

        mouse_pos = pygame.mouse.get_pos()
        (mouse_pos_x, mouse_pos_y) = mouse_pos
        if (mouse_pos_x >= (screen_width - start_width) / 2 and mouse_pos_x <= (screen_width + start_width) / 2 and
                mouse_pos_y >= (screen_height - start_height) / 2 and mouse_pos_y <= (screen_height + start_height) / 2):
            # Mouse over the button
            start_button_layer.fill((0, 0, 0, 0))  # Make it transparent
            Start_button.Draw_image(start_button_layer2, 0, 0, start_width2, start_height2)
            screen.blit(start_button_layer2, ((screen_width - start_width2) / 2, (screen_height - start_height2) / 2))
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    time.sleep(1)
                    Mode=ControlMode.LOADING_MODE
                    Start_button=None
                    Start_button=None
                    start_button_layer=None
                    start_button_layer2=None
                    return
        else:
            # Mouse out of the button
            start_button_layer2.fill((0, 0, 0, 0))  # Make it transparent
            Start_button.Draw_image(start_button_layer, 0, 0, start_width, start_height)
            screen.blit(start_button_layer, ((screen_width - start_width) / 2, (screen_height - start_height) / 2))

        pygame.display.flip()  # Update display after every event


def _LOADING_MODE():
    background_layer.fill((255, 255, 255))
    screen.blit(background_layer, (0, 0))
    pygame.display.flip()
    global Mode
    Mode=ControlMode.PLAY_MODE
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Mode = ControlMode.EXIT_MODE
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                Mode = ControlMode.EXIT_MODE
                return


def _PLAY_MODE():
    game_map=Map("map1.txt")
    screen.blit(game_map.map_image_layer,(-20, -20))
    pygame.display.flip()
    global Mode
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Mode = ControlMode.EXIT_MODE
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                Mode = ControlMode.EXIT_MODE
                return

def _EXIT_MODE():
    pygame.quit()
    sys.exit()


def main_code():
    global Mode
    if Mode == ControlMode.INIT_MODE:
        _INIT_MODE()
    elif Mode == ControlMode.EXIT_MODE:
        _EXIT_MODE()
    elif Mode == ControlMode.MAIN_INTERGACE_MODE:
        _MAIN_INTERGACE_MODE()
    elif Mode== ControlMode.LOADING_MODE:
        _LOADING_MODE()
    elif Mode==ControlMode.PLAY_MODE:
        _PLAY_MODE()


############### Main while #########
while True:
    main_code()
