import pygame
import sys
import time
from enum import Enum
import os


# Define all the MODE here 
class ControlMode(Enum):
    INIT_MODE = 0
    MAIN_INTERGACE_MODE = 1
    LOADING_MODE=2
    PLAY_MODE=3
    EXIT_MODE = 100

###################### All the variables are defined here #################
Mode = ControlMode.INIT_MODE  # When change the value of Mode, please use Mode=ControlMode.**_MODE
screen_width = 0
screen_height = 0
brick_len=0
title = ''
left_click = False
brick_address_list=[]
brick_list=[]
brick_movable=[]
brick_number=0
current_file_dir=""

def varibles_init():
    global Mode, screen_width, screen_height, title,left_click,brick_len,brick_number,current_file_dir
    Mode = ControlMode.INIT_MODE
    screen_width = 800
    screen_height = 600
    title = "game"
    left_click = False
    brick_len=50
    brick_number=10
    current_file_dir = os.path.dirname(os.path.abspath(__file__))+"\\"

class Brick:
    def __init__(self, brick_id):
        self.brick_id=brick_id
        self.loadimage=pygame.image.load(current_file_dir+brick_address_list[brick_id])
        self.image=pygame.transform.scale(self.loadimage,(brick_len,brick_len))
        
def brick_address_list_init():
    global brick_address_list,brick_number,brick_movable
    for i in range(brick_number):
        brick_address_list.append(str(i)+".png")
        brick_list.append(Brick(i))
        brick_movable.append(1)
    brick_movable=[0,0,0,0,0,0,0,0,0,1]
##################### Some init #################
pygame.init()
varibles_init()
brick_address_list_init()
screen = pygame.display.set_mode((screen_width, screen_height))
background_layer = pygame.Surface((screen_width, screen_height))  # Background layer
pygame.display.set_caption(title)
Mode = ControlMode.MAIN_INTERGACE_MODE



# character_layer = pygame.Surface((800, 600), pygame.SRCALPHA)  # Character layer, supports transparency
# ui_layer = pygame.Surface((800, 600), pygame.SRCALPHA)


class Image:
    def __init__(self, address):
        self.address = address
        self.image = pygame.image.load(current_file_dir+address)
        self.image_width = self.image.get_width()
        self.image_height = self.image.get_height()

    def Draw_image(self, layer, x, y, need_width, need_height):
        layer.blit(pygame.transform.scale(self.image, (need_width, need_height)), (x, y))

    def Draw_image_MID(self, layer, x, y, need_width, need_height):
        layer.blit(pygame.transform.scale(self.image, (need_width, need_height)), (x - need_width / 2, y - need_height / 2))

class Inventory:
    def __init__(self):
        self.address="inventory.jpg"
        self.image=Image(self.address)
        self.width=screen_width/80*18
        self.height=screen_height/10
        self.layer=pygame.Surface((self.width,self.height))
        self.image.Draw_image(self.layer,0,0,self.width,self.height)
        self.start_x,self.start_y=screen_width/2-self.width/2,screen_height/10*17/2
        self.item=[]*3
        self.highlight_address=""
        self.highlight_image=Image("inventory_highlight.jpg")
        self.highlight_layer=pygame.Surface((self.height,self.height))
        self.highlight_image.Draw_image(self.highlight_layer,0,0,self.height,self.height)
        
    def draw_inventory(self,item_number):
        screen.blit(self.layer, (self.start_x,self.start_y))
        if(item_number!=-1):
            screen.blit(self.highlight_layer, (self.start_x+item_number*self.height,self.start_y))


class Character:
    def __init__(self, address):
        self.address=address
        self.width=brick_len
        self.height=brick_len*2
        self.image=Image(address)
        self.layer=pygame.Surface((self.width,self.height),pygame.SRCALPHA)
        self.image.Draw_image(self.layer,0,0,self.width,self.height)
        self.dirction=0       #0 front 1 left 2 back 3 right
        self.pos_x=0
        self.pos_y=0
        self.invertory=Inventory()
        self.item_number=-1
        self.last_item_number=0
        
               
class Map:
    def __init__(self, address):
        self.address=address
        with open(current_file_dir+self.address, "r") as file:
            self.brick_number_x, self.brick_number_y = map(int, file.readline().split())
            self.matrix=[list(map(int, line.split())) for line in file]
        self.total_width,self.total_height=self.brick_number_x*brick_len,self.brick_number_y*brick_len
        self.map_image_layer=pygame.Surface((self.total_width,self.total_height))
        for i in range(self.brick_number_x):
            for j in range(self.brick_number_y):
                self.map_image_layer.blit(brick_list[self.matrix[j][i]].image,(i*brick_len,j*brick_len))               

class Button:
    def __init__(self, image, mid_x,mid_y,width,height,ratio):
        self.image=image
        self.mid_x, self.mid_y = mid_x,mid_y
        self.width,self.height=width,height
        self.start_x,self.end_x,self.start_y,self.end_y=mid_x-width/2,mid_x+width/2,mid_y-height/2,mid_y+height/2
        self.layer = pygame.Surface((self.width,self.height), pygame.SRCALPHA)
        self.image.Draw_image(self.layer,0,0,width,height)
        self.width2,self.height2 = self.width*ratio, self.height*ratio
        self.start_x2,self.start_y2=mid_x-self.width2/2,mid_y-self.height2/2
        self.layer2 = pygame.Surface((self.width2, self.height2), pygame.SRCALPHA)
        
    def draw_button(self,mouse_pos,event):
        (mouse_pos_x, mouse_pos_y) = mouse_pos
        if(mouse_pos_x>=self.start_x and mouse_pos_x<=self.end_x and mouse_pos_y>=self.start_y and mouse_pos_y<=self.end_y):
            # Mouse over the button
            self.layer.fill((0, 0, 0, 0))  # Make it transparent
            self.image.Draw_image(self.layer2, 0, 0, self.width2,self.height2)
            screen.blit(self.layer2, (self.start_x2,self.start_y2))
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    return 1
            return 0
        else:
            # Mouse out of the button
            self.layer2.fill((0, 0, 0, 0))  # Make it transparent
            self.image.Draw_image(self.layer, 0, 0, self.width,self.height)
            screen.blit(self.layer, (self.start_x,self.start_y))
            return 0
        

        
        

game_map=Map("map1.txt")
user_character=Character("pic1.png")        
# all the MODE should be defined as _**_MODE and have the following code
def _INIT_MODE():
    global Mode
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Mode = ControlMode.EXIT_MODE
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                Mode = ControlMode.EXIT_MODE
                return



def _MAIN_INTERGACE_MODE():
    global Mode
    background_layer.fill((255, 255, 255))  # Clear the background layer
    screen.blit(background_layer, (0, 0))
    Start_button = Button(Image('start.png'),screen_width/2,screen_height/2,screen_width/4,screen_height/4,1.2)
    

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Mode = ControlMode.EXIT_MODE
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                Mode = ControlMode.EXIT_MODE
                return

        mouse_pos = pygame.mouse.get_pos()
        if Start_button.draw_button(mouse_pos,event):
            Mode=ControlMode.LOADING_MODE
            Start_button=None
            return

        pygame.display.flip()  # Update display after every event


def _LOADING_MODE():
    global user_character,game_map
    background_layer.fill((255, 255, 255))
    screen.blit(background_layer, (0, 0))
    pygame.display.flip()
    global Mode
    game_map=Map("map1.txt")
    user_character=Character("pic1.png")  
    user_character.pos_x=5
    user_character.pos_y=2
    Mode=ControlMode.PLAY_MODE
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Mode = ControlMode.EXIT_MODE
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                Mode = ControlMode.EXIT_MODE
                return




def wasd_move(pos_x,pos_y,move):
    if move==0:
        return pos_x,pos_y-1
    elif move==1:
        return pos_x-1,pos_y
    elif move==2:
        return pos_x,pos_y+1
    elif move==3:
        return pos_x+1,pos_y

def brick_legal(pos_x,pos_y):
    global brick_movable,game_map
    if(pos_x>=0 and pos_x<game_map.brick_number_x and pos_y>=0 and pos_y<game_map.brick_number_y):
        if brick_movable[game_map.matrix[pos_y][pos_x]]:
            return 1
    return 0

def move_legal(move):
    if move==-1: return 0
    if move==0 or move==1 or move==2 or move==3:
        new_pos_x,new_pos_y=wasd_move(user_character.pos_x,user_character.pos_y,move)
        if(brick_legal(new_pos_x,new_pos_y)):
            return 1
    return 0

def draw_map_user_character():
    layer_left,layer_up=screen_width/2-brick_len/2-brick_len*user_character.pos_x,screen_height/2-brick_len*user_character.pos_y,
    layer_right,layer_down=layer_left+game_map.brick_number_x*brick_len,layer_up+game_map.brick_number_y*brick_len
    character_x,character_y=screen_width/2-brick_len/2,screen_height/2-brick_len
    
    if layer_left>0:
        layer_left,layer_right,character_x=0,layer_right-layer_left,character_x-layer_left
    if(layer_right<screen_width):
        layer_left,layer_right,character_x=layer_left+screen_width-layer_right,screen_width,character_x+screen_width-layer_right
    if layer_up>0:
        layer_up,layer_down,character_y=0,layer_down-layer_up,character_y-layer_up
    if(layer_down<screen_height):
        layer_up,layer_down,character_y=layer_up+screen_height-layer_down,screen_height,character_y+screen_height-layer_down
    screen.blit(game_map.map_image_layer,(layer_left,layer_up))
    screen.blit(user_character.layer,(character_x,character_y))
    
def _PLAY_MODE():
    global user_character,game_map
    draw_map_user_character()
    user_character.invertory.draw_inventory(user_character.item_number)
    pygame.display.flip()
    global Mode
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Mode = ControlMode.EXIT_MODE
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                Mode = ControlMode.EXIT_MODE
                return
        
        if event.type== pygame.KEYDOWN:
            player_move=-1
            if event.key==pygame.K_w:
                player_move=0
            elif event.key==pygame.K_a:
                player_move=1
            elif event.key==pygame.K_s:
                player_move=2
            elif event.key==pygame.K_d:
                player_move=3
            elif event.key==pygame.K_1:
                if(user_character.item_number==0):
                    user_character.item_number=-1
                else:
                    user_character.item_number=0
                user_character.last_item_number=0
                player_move=4
            elif event.key==pygame.K_2:
                if(user_character.item_number==1):
                    user_character.item_number=-1
                else:
                    user_character.item_number=1
                user_character.last_item_number=1
                player_move=4
            elif event.key==pygame.K_3:
                if(user_character.item_number==2):
                    user_character.item_number=-1
                else:
                    user_character.item_number=2
                user_character.last_item_number=2
                player_move=4
            elif event.key==pygame.K_q:
                user_character.item_number=(user_character.last_item_number+2)%3
                user_character.last_item_number=user_character.item_number
                player_move=4
            elif event.key==pygame.K_e:
                user_character.item_number=(user_character.last_item_number+1)%3
                user_character.last_item_number=user_character.item_number
                player_move=4
            
            if move_legal(player_move)==1:
                user_character.pos_x,user_character.pos_y=wasd_move(user_character.pos_x,user_character.pos_y,player_move)

def _EXIT_MODE():
    pygame.quit()
    sys.exit()


def main_code():
    global Mode
    if Mode == ControlMode.INIT_MODE:
        _INIT_MODE()
    elif Mode == ControlMode.EXIT_MODE:
        _EXIT_MODE()
    elif Mode == ControlMode.MAIN_INTERGACE_MODE:
        _MAIN_INTERGACE_MODE()
    elif Mode== ControlMode.LOADING_MODE:
        _LOADING_MODE()
    elif Mode==ControlMode.PLAY_MODE:
        _PLAY_MODE()


############### Main while #########
while True:
    main_code()
