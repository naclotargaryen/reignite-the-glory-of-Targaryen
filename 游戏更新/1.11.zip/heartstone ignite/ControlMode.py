from enum import Enum

class ControlMode(Enum):
    INIT_MODE = 0
    MAIN_INTERGACE_MODE = 1
    LOADING_MODE=2
    PLAY_MODE=3
    LAYING_MODE=4
    EXIT_MODE = 100


