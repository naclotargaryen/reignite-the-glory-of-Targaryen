import pygame
from Button import *
from enum import Enum

class GameState(Enum):
    INIT = 0
    MAIN_INTERGACE = 1
    LOADING=2
    PLAY=3
    LAYING=4
    EXIT= 100


class ScreenSetting:
     screen_width = 800
     screen_height = 600
     title = "game"

class BrickSetting:
    brick_len=50
    brick_number=10 
    brick_movable=[0,0,0,0,0,0,0,0,0,1]
    brick_address_list=[]
    brick=[]
    for i in range(brick_number):
        brick_address_list.append("./Images/Brick/"+str(i)+".png")


        
class Mainintergace:
    Start_button = Button(Image('./Images/Mainintergace/start.png'),ScreenSetting.screen_width/2,ScreenSetting.screen_height/2,ScreenSetting.screen_width/4,ScreenSetting.screen_height/4,1.2)

class UserCharacterSetting:
    address_front ='./Images/UserCharacter/pic_front.png'
    address_left = './Images/UserCharacter/pic_left.png'
    address_back = './Images/UserCharacter/pic_back.png'
    address_right = './Images/UserCharacter/pic_right.png'
    width=BrickSetting.brick_len
    height=BrickSetting.brick_len * 2
    pic=[]
    pic.append(Image(address_front))
    pic.append(Image(address_left))
    pic.append(Image(address_back))
    pic.append(Image(address_right))
    

class InventorySetting:
     address="Images/inventory.jpg"
     highlight_address="./Images/inventory_highlight.jpg"
     image=Image(address)
     highlight_image=Image(highlight_address)
     width=ScreenSetting.screen_width/80*18
     height=ScreenSetting.screen_height/10
     layer=pygame.Surface((width,height))
     image.Draw_image(layer,0,0,width,height)
     start_x,start_y=ScreenSetting.screen_width/2-width/2,ScreenSetting.screen_height/10*17/2
     
class MapSetting:
    map_number=1
    map_address_list=[]
    mmaps=[]
    for i in range(map_number):
        map_address_list.append("./Map/map"+str(i)+".txt")