import pygame
from Settings import *
from Image import *
from Inventory import *
class UserCharacter:
    def __init__(self):
        
        self.image = UserCharacterSetting.pic[0]
        self.layer = pygame.Surface((UserCharacterSetting.width, UserCharacterSetting.height), pygame.SRCALPHA)
        self.image.Draw_image(self.layer, 0, 0, UserCharacterSetting.width, UserCharacterSetting.height)
        
        self.direction=0       #0 front 1 left 2 back 3 right
        self.pos_x=0
        self.pos_y=0
        self.inventory=Inventory()
        self.item_number=-1
        self.last_item_number=0
        self.laying_pos_x=0
        self.laying_pos_y=0
        self.sword=0
        self.win=0
        
    def update_direction(self, move):
        if move<=3:
            if move==0:
                self.direction=2
            elif move==1:
                self.direction=1
            elif move==2:
                self.direction=0
            elif move==3:
                self.direction=3
                
            self.image = UserCharacterSetting.pic[self.direction]

            self.layer = pygame.Surface((UserCharacterSetting.width, UserCharacterSetting.height), pygame.SRCALPHA)
            self.image.Draw_image(self.layer, 0, 0, UserCharacterSetting.width, UserCharacterSetting.height)
    def rotate_item(self,n):
        if(self.inventory.item[n].flag):
            new_matrix = [[0 for _ in range(self.inventory.item[n].rows)] for _ in range(self.inventory.item[n].cols)]
            for i in range(self.inventory.item[n].cols):
                for j in range(self.inventory.item[n].rows):
                    new_matrix[i][j]=self.inventory.item[n].matrix[self.inventory.item[n].rows-1-j][i]
            self.inventory.item[n]=Item(new_matrix)