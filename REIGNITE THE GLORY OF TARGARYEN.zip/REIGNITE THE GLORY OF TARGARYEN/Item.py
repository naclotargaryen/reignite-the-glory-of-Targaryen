import pygame
from Settings import *
from Image import *
from Staffs import *

class Item:
    def __init__(self,matrix):
        self.flag=1
        self.matrix=matrix
        self.rows = len(self.matrix)
        self.cols = len(matrix[0])   
        self.layer= pygame.Surface((self.cols*BrickSetting.brick_len, self.rows*BrickSetting.brick_len), pygame.SRCALPHA)
        
        
        for i in range(self.rows):
            for j in range(self.cols):
                brick_num=self.matrix[i][j]
                if(brick_num!=-1):
                    self.layer.blit(Bricks.List[brick_num].image,(j*BrickSetting.brick_len,i*BrickSetting.brick_len))
        
        self.inventory_layer_width,self.inventory_layer_height=0,0
        if(self.rows>=self.cols):
            self.inventory_layer_width,self.inventory_layer_height=ScreenSetting.screen_width/20*self.cols/self.rows,ScreenSetting.screen_width/20
        else:
            self.inventory_layer_width,self.inventory_layer_height=ScreenSetting.screen_width/20,ScreenSetting.screen_width/20*self.rows/self.cols
        self.inventory_layer=pygame.Surface((self.inventory_layer_width,self.inventory_layer_height),pygame.SRCALPHA)
        self.inventory_layer.blit(pygame.transform.scale(self.layer, (self.inventory_layer_width,self.inventory_layer_height)),(0,0))