#three_eyed_crow_npc

from openai import OpenAI
from typing import List, Dict


# 定义LLMAgent类来与语言大模型进行交互
class LLMAgent:
    def __init__(self):
        self.client = OpenAI(
            base_url='http://10.15.88.73:5023/v1', 
            api_key='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',  # 填入你的API密钥
        )

    def send_message(self, message: str) -> str:
        """
        发送用户消息并获取助手的回复。
        """
        try:
            response = self.client.chat.completions.create(
                model="llama3.2", 
                messages=[{"role": "user", "content": message}]
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            return f"发生了错误: {e}"

# 定义游戏中的NPC0 三眼乌鸦
class NPC0:
    def __init__(self, name: str, agent: LLMAgent):
        self.name = name
        self.agent = agent

    def greet_player(self, player_name: str) -> str:
        """
        NPC 在玩家进入游戏后，生成一段欢介绍词。
        使用玩家的姓名来进行个性化的问候。
        """
        greeting_message = f",{player_name}，·史文，你刚刚看书睡着了，我是三眼乌鸦"
        response = self.agent.send_message(greeting_message)  # 通过语言大模型生成回应
        return response

# 游戏开始函数
def start_game():
    player_name = input("请输入你的名字：")  # 让玩家输入自己的名字
    agent = LLMAgent()  # 创建LLMAgent实例
    npc = NPC0(name="探险者", agent=agent)  # 创建NPC实例

    print(f"游戏开始！")
    input("按回车继续...")
    print(f"你现在维斯特洛大陆的石盔城，{player_name}·史文。")
    input("按回车继续...")
    print(f"刚睡醒来你可能脑子不太清楚，让我来给你讲讲发生了什么")
    input("按回车继续...")
    print(f"五王之战结束多年后，七大家族的根基已然动摇。尽管表面上各家族名义上仍占据着广阔的领土，实际上的控制力却大不如前。君临的统治者在与外敌的多次战争中几近虚弱，王座之下的权力早已是名存实亡。各大家族的内讧和争斗愈加激烈，似乎每个人都在谋划着如何从这场权力的游戏中脱颖而出。")
    input("按回车继续...")
    print(f"无论是兰尼斯特家族的金钱与权谋，还是史塔克家族的忠诚与名誉，抑或是葛雷乔伊家族的野心，所有人都为了自己的利益彼此勾心斗角，撕裂了维斯特洛本已脆弱的秩序。")
    input("按回车继续...")
    print(f"当严冬的寒风再次侵袭维斯特洛时，许多小家族因无法抵御食物与燃料短缺的双重打击，纷纷崩溃或被推翻。那些依靠土地与民众生存的小家族，最终沦为更强大家族的吞并对象。在这场资源与生存的斗争中，旧日的荣光早已消失殆尽，只有残酷与无情的现实才是维斯特洛的主旋律。")
    input("按回车继续...")
    print(f"而在这些纷争的背后，长城的守卫者和那些坚守在极北的野人们正面临着一个更为可怕的威胁——异鬼。随着北方的寒气愈发肆虐，异鬼的侵袭逐渐变得无法忽视。无数家族纷纷将目光集中在自己的权力斗争上，唯一有意联合抵抗的是史塔克家族、丹妮莉丝和一些忠诚于家园的勇士，但这些力量依旧微弱无力，面对如潮水般涌来的异鬼，他们的努力最终未能阻止长城的破裂。异鬼带着无尽的寒气，逐渐突破长城，南下侵袭一切。")
    input("按回车继续...")
    print(f"你是一个出生于石盔城的史文家族的小孩。从小你便对历史和故事充满热情，尤其是关于坦格利安家族的传奇。你梦想着有朝一日能够像那位大王——伊耿·坦格利安——一样，驾驭龙与火，统一这片战乱不断的大陆。尽管你的家族并不显赫，甚至在当地不过是一个不起眼的小家族，但你对知识的渴望和对历史的沉迷让你在石盔城的图书馆中度过了大多数时光")
    input("按回车继续...")
    print(f"在一次偶然的机会中，你发现了古老的书卷中隐藏的秘密——龙蛋，尚未孵化的龙蛋会在途经的地方遗留龙之精华。传说中，收集这些龙之精华并经过某种神秘的仪式，可以复活龙，而不同种类的龙精华合并后，有可能唤醒前所未有的强大龙。")
    input("按回车继续...")
    print(f"在这个绝望的时代，当异鬼步步紧逼，龙的力量成为了你心中唯一的希望。你决定重走丹妮莉丝·坦格利安的足迹，寻找散落的龙之精华，复活强大的龙，重新点燃坦格利安家族的荣耀，为这片被寒风笼罩的大地带来一线生机。你也明白，复兴坦格利安不仅是对龙的复苏，更是对失落秩序的重建，是对人民一个不再畏惧寒冬与异鬼的承诺。")
    input("按回车继续...")
    print(f"然而，寻找这些龙之精华并非易事。每一块精华都埋藏在深不见底的废墟之中，或是跨越重重险阻的古老遗迹，而这些地方早已被异鬼和敌对家族所占据。你的冒险之路，将是一条充满危险、背叛与挑战的道路——但如果你能够成功复活龙，并联合各方力量，你或许能重建那个曾经统治七大王国的黄金时代。")
    input("按回车继续...")
    print(f"现在你将踏上寻找龙之精华的旅途，我将为你提供指引。")

    

    # NPC0 对话
    npc0_greeting = npc.greet_player(player_name)
    print(f"NPC0:{npc0_greeting}")  # 打印NPC说的话

# 启动游戏
start_game()