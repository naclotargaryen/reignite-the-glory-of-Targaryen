#决策
from openai import OpenAI
from typing import List, Dict

# 假设我们已经有了一个OpenAI的客户端对象
class LLMAgent:
    def __init__(self):
        self.client = OpenAI(
            base_url='http://10.15.88.73:5023/v1',  # 更新为你的实际服务器地址
            api_key='ollama',  # 更新为你实际的API密钥
        )

# 定义自由贸易商人的决策代理类
class LLMTradeAgent(LLMAgent):
    def __init__(self):
        super().__init__()
        self.messages: List[Dict] = [
            {"role": "system", "content": (
                "商人：欢迎来到我的店铺！我有两种交易方式。\n"
                "1. 购买方块和书籍，你将获得一块方块和一本神秘书籍。\n"
                "2. 购买方块和武器，你将获得一块方块和一把强力武器。\n"
                "你必须做出选择：购买方块和书籍，还是方块和武器？"
            )}
        ]
    
    def make_decision(self, player_money: int, player_choice: str) -> str:
        """
        玩家做出选择后，商人根据玩家选择给予反馈。
        :param player_money: 玩家当前的金钱数
        :param player_choice: 玩家选择的选项（'books' 或 'weapons'）
        :return: 商人对玩家选择的反馈
        """
        self.messages.append({"role": "user", "content": player_choice})

        try:
            # 调用语言大模型进行决策生成
            response = self.client.chat.completions.create(
                model="llama3.2",
                messages=self.messages,
            )
            assistant_reply = response.choices[0].message.content.strip()
        except Exception as e:
            assistant_reply = "抱歉，发生了一个错误。"

        self.messages.append({"role": "assistant", "content": assistant_reply})

        # 处理商人根据玩家选择的反馈
        if player_choice == "books":
            if player_money >= 20:
                return f"商人：你选择了方块和书籍。你支付了20金币，获得了一块方块和一本书籍。"
            else:
                return f"商人：你没有足够的金钱购买方块和书籍。"
        elif player_choice == "weapons":
            if player_money >= 30:
                return f"商人：你选择了方块和武器。你支付了30金币，获得了一块方块和一把强力武器。"
            else:
                return f"商人：你没有足够的金钱购买方块和武器。"
        else:
            return "商人：你没有做出有效的选择，请选择 'books' 或 'weapons'。"

# 下面是与玩家交互的代码，模拟玩家做出选择
def interact_with_trader():
    print("商人：欢迎来到我的店铺！你可以选择以下两种交易方式：")
    print("1. 购买方块和书籍（20金币）")
    print("2. 购买方块和武器（30金币）")
    print("请做出选择：'books' 或 'weapons'")

    player_choice = input("你的选择是：").strip().lower()
    player_money = 50  # 假设玩家初始有50金币
    
    trade_agent = LLMTradeAgent()
    result = trade_agent.make_decision(player_money, player_choice)
    
    print(result)

# 调用与商人的互动
interact_with_trader()
