import pygame

class Image:
    def __init__(self, address):
        self.address = address
        self.image = pygame.image.load(address)
        self.image_width = self.image.get_width()
        self.image_height = self.image.get_height()

    def Draw_image(self, layer, x, y, need_width, need_height):
        layer.blit(pygame.transform.scale(self.image, (need_width, need_height)), (x, y))

    def Draw_image_MID(self, layer, x, y, need_width, need_height):
        layer.blit(pygame.transform.scale(self.image, (need_width, need_height)), (x - need_width / 2, y - need_height / 2))