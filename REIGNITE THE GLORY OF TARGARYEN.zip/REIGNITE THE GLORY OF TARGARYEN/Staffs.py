from Settings import *
from Brick import *
from Map import *
from NPC import *
class Bricks:
     List=[]
     for i in range(BrickSetting.brick_number):
        List.append(Brick(i))
        
class Maps:
    List=[]
    for i in range(MapSetting.map_number):
         List.append(Map(i,Bricks.List))

class NPCs:
    List=[]
    for i in range(NPCSetting.number):
        List.append(NPC(i))
