import pygame
from Image import *
class Button:
    def __init__(self, image, mid_x,mid_y,width,height,ratio):
        self.image=image
        self.mid_x, self.mid_y = mid_x,mid_y
        self.width,self.height=width,height
        self.start_x,self.end_x,self.start_y,self.end_y=mid_x-width/2,mid_x+width/2,mid_y-height/2,mid_y+height/2
        self.layer = pygame.Surface((self.width,self.height), pygame.SRCALPHA)
        self.image.Draw_image(self.layer,0,0,width,height)
        self.width2,self.height2 = self.width*ratio, self.height*ratio
        self.start_x2,self.start_y2=mid_x-self.width2/2,mid_y-self.height2/2
        self.layer2 = pygame.Surface((self.width2, self.height2), pygame.SRCALPHA)
        
    def draw_button(self,mouse_pos,screen):
        (mouse_pos_x, mouse_pos_y) = mouse_pos
        if(mouse_pos_x>=self.start_x and mouse_pos_x<=self.end_x and mouse_pos_y>=self.start_y and mouse_pos_y<=self.end_y):
            # Mouse over the button
            self.layer.fill((0, 0, 0, 0))  # Make it transparent
            self.image.Draw_image(self.layer2, 0, 0, self.width2,self.height2)
            screen.blit(self.layer2, (self.start_x2,self.start_y2))
            return 1
        else:
            # Mouse out of the button
            self.layer2.fill((0, 0, 0, 0))  # Make it transparent
            self.image.Draw_image(self.layer, 0, 0, self.width,self.height)
            screen.blit(self.layer, (self.start_x,self.start_y))
            return 0
        