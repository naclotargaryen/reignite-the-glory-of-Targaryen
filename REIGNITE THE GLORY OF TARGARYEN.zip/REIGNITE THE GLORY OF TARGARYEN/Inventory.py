import pygame
from Settings import *
from Image import *
from Item import *
class Inventory:
    def __init__(self):
                 
        self.layer=pygame.Surface((InventorySetting.width,InventorySetting.height))
        InventorySetting.image.Draw_image(self.layer,0,0,InventorySetting.width,InventorySetting.height)
        self.item=[]
        for i in range(3):
            self.item.append(Item([[0]]))
            self.item[i].flag=0
        self.highlight_layer=pygame.Surface((InventorySetting.height,InventorySetting.height))
        InventorySetting.highlight_image.Draw_image(self.highlight_layer,0,0,InventorySetting.height,InventorySetting.height)
        
    def draw_inventory(self,item_number,screen):
        screen.blit(self.layer, (InventorySetting.start_x,InventorySetting.start_y))
        if(item_number!=-1):
            screen.blit(self.highlight_layer, (InventorySetting.start_x+item_number*InventorySetting.height,InventorySetting.start_y))
        for i in range(3):
            if(self.item[i].flag):
                screen.blit(self.item[i].inventory_layer,(InventorySetting.start_x+InventorySetting.height/2-self.item[i].inventory_layer_width/2+InventorySetting.height*i,InventorySetting.start_y+InventorySetting.height/2-self.item[i].inventory_layer_height/2))