#music
import pygame
import time


class Music:
    pygame.mixer.init()
    pygame.mixer.music.load('./Music/1.mp3')  # 请替换为你实际的音乐文件路径


