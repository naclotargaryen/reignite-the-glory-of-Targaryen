import pygame
from Settings import *
from Image import *




class Map:
    def __init__(self,id,brick):
        with open(MapSetting.map_address_list[id], "r") as file:
            self.brick_number_rows, self.brick_number_cols = map(int, file.readline().split())
            self.matrix=[list(map(int, line.split())) for line in file]
        self.total_width,self.total_height=self.brick_number_cols*BrickSetting.brick_len,self.brick_number_rows*BrickSetting.brick_len
        self.map_image_layer=pygame.Surface((self.total_width,self.total_height))
        for i in range(self.brick_number_rows):
            for j in range(self.brick_number_cols):
                self.map_image_layer.blit(brick[self.matrix[i][j]].image,(j*BrickSetting.brick_len,i*BrickSetting.brick_len))               

    def update(self,brick):
        for i in range(self.brick_number_rows):
            for j in range(self.brick_number_cols):
                self.map_image_layer.blit(brick[self.matrix[i][j]].image,(j*BrickSetting.brick_len,i*BrickSetting.brick_len))    
        
    def calc_topleft(self,user):
        layer_left,layer_top=ScreenSetting.screen_width/2-BrickSetting.brick_len/2-BrickSetting.brick_len*user.pos_x,ScreenSetting.screen_height/2-BrickSetting.brick_len*user.pos_y,
        layer_right,layer_bottom=layer_left+self.brick_number_cols*BrickSetting.brick_len,layer_top+self.brick_number_rows*BrickSetting.brick_len
        character_x,character_y=ScreenSetting.screen_width/2-BrickSetting.brick_len/2,ScreenSetting.screen_height/2-BrickSetting.brick_len
    
        if layer_left>0:
            layer_left,layer_right,character_x=0,layer_right-layer_left,character_x-layer_left
        if(layer_right<ScreenSetting.screen_width):
            layer_left,layer_right,character_x=layer_left+ScreenSetting.screen_width-layer_right,ScreenSetting.screen_width,character_x+ScreenSetting.screen_width-layer_right
        if layer_top>0:
            layer_top,layer_bottom,character_y=0,layer_bottom-layer_top,character_y-layer_top
        if(layer_bottom<ScreenSetting.screen_height):
            layer_top,layer_bottom,character_y=layer_top+ScreenSetting.screen_height-layer_bottom,ScreenSetting.screen_height,character_y+ScreenSetting.screen_height-layer_bottom
        return (layer_top,layer_left,character_x,character_y)