import tkinter as tk
from openai import OpenAI
from typing import List, Dict


class LLMAgent:
    def __init__(self):
        self.client = OpenAI(
            base_url='http://10.15.88.73:5023/v1',
            api_key='ollama',
        )


class LLMTradeAgent(LLMAgent):
    def __init__(self):
        super().__init__()
        self.messages: List[Dict] = [
            {"role": "system", "content": (
                "Businessman: Welcome to my shop! Today's new customer offer, you can choose a free product to take away! "
                "You can choose to buy yellow blocks (worth 20 gold coins) or blue blocks (worth 30 gold coins). "
                "Please enter a selection: 'yellow' or 'blue'."
            )}
        ]

    def make_decision(self, player_money: int, player_choice: str) -> str:
        self.messages.append({"role": "user", "content": player_choice})

        try:
            response = self.client.chat.completions.create(
                model="llama3.2",
                messages=self.messages,
            )
            assistant_reply = response.choices[0].message.content.strip()
        except Exception as e:
            assistant_reply = "Sorry, an error has occurred."

        self.messages.append({"role": "assistant", "content": assistant_reply})

        if player_choice == "yellow":
            return 1
        elif player_choice == "blue":
            return 2
        else:
            return 0


def ask_businessman():
    def on_submit():
        nonlocal result
        player_choice = input_entry.get().strip().lower()
        player_money = 50
        trade_agent = LLMTradeAgent()
        result = trade_agent.make_decision(player_money, player_choice)
        window.destroy()  # Close the window after submission

    window = tk.Tk()
    window.title("Businessman")

    label = tk.Label(
        window,
        text=(
            "Businessman: Welcome to my shop! Today's new customer offer, you can choose a free product to take away! "
            "You can choose to buy yellow blocks (worth 20 gold coins) or blue blocks (worth 30 gold coins).\n"
            "Please enter a selection: 'yellow' or 'blue'."
        ),
    )
    label.pack()

    input_entry = tk.Entry(window)
    input_entry.pack()

    submit_button = tk.Button(window, text="Submit", command=on_submit)
    submit_button.pack()

    result = None
    window.mainloop()
    return result
