import pygame
from Settings import *
from Image import *

class NPC:
    def __init__(self,id):
        self.layer = pygame.Surface((NPCSetting.width[id], NPCSetting.height[id]), pygame.SRCALPHA)
        NPCSetting.image[id].Draw_image(self.layer, 0, 0, UserCharacterSetting.width, UserCharacterSetting.height)
        self.if_appear=1
        self.locate=NPCSetting.locate[id]
        self.height=NPCSetting.height[id]
        self.width=NPCSetting.width[id]
    def draw(self,screen,maptop,mapleft):
        top=self.locate[2]*BrickSetting.brick_len+maptop-self.height
        left=self.locate[1]*BrickSetting.brick_len+mapleft-self.width
        screen.blit(self.layer,(left,top))