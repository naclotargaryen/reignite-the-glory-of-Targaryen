import time
from turtle import Screen
import pygame
import sys
from Settings import *
from Button import *
from Brick import *
from Map import *
from UserCharacter import *
from move_fuc import *
from laying_fuc import *
from Music import *
from Talking import *
import string
from Decision import *
class GameManager:
    def __init__(self):
        
        self.screen = pygame.display.set_mode((ScreenSetting.screen_width, ScreenSetting.screen_height))
        self.background_layer = pygame.Surface((ScreenSetting.screen_width, ScreenSetting.screen_height))
        pygame.display.set_caption(ScreenSetting.title)
        self.state=GameState.MAIN_INTERGACE
        self.user=UserCharacter()
        self.mapid=1
        self.mmap=Maps.List[self.mapid]
        self.user.pos_x=5
        self.user.pos_y=2
        self.Taking_to=-1
        pygame.mixer.music.play(-1)




    def main_code(self):
        
        if self.state == GameState.INIT:
            

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.state=GameState.EXIT
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.state=GameState.EXIT
                        return
                 


        elif self.state== GameState.MAIN_INTERGACE:
            

            
            self.background_layer = pygame.Surface((ScreenSetting.screen_width, ScreenSetting.screen_height))
            self.background_layer.blit(Mainintergace.cover.image,(0,0))

            self.screen.blit(self.background_layer, (0, 0))
            mouse_pos = pygame.mouse.get_pos()
            flag=Mainintergace.Start_button.draw_button(mouse_pos,self.screen)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.state=GameState.EXIT
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.state=GameState.EXIT
                        return

                if flag and event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        self.state=GameState.PLAY
                        return
                pygame.display.flip()
        


        elif self.state== GameState.EXIT:
            

            pygame.quit()
            sys.exit()
            

        elif self.state==GameState.PLAY:
            if(self.mapid==2):
                if(get_sword(self.mmap)):
                    self.user.sword=1
                    print(1)
                    self.mmap=Maps.List[0]
                    self.mmap.update(Bricks.List)

            layer_top,layer_left,user_top,user_left=self.mmap.calc_topleft(self.user)
            self.screen.blit(self.mmap.map_image_layer,(layer_left,layer_top))
            for i in range(NPCSetting.number):
                if(NPCSetting.locate[i][0]==self.mapid):
                    NPCs.List[i].draw(self.screen,layer_top,layer_left)
            self.screen.blit(self.user.layer,(user_top,user_left))
            self.user.inventory.draw_inventory(self.user.item_number,self.screen)
            

            time.sleep(0.05)
            
            


            if_trans=is_trans([self.mapid,self.user.pos_x,self.user.pos_y])
            if(if_trans!=-1):
                Maps.List[self.mapid]=self.mmap
                self.mapid=TransPoint.List2[if_trans][0]
                self.mmap=Maps.List[self.mapid]
                self.user.pos_x=TransPoint.List2[if_trans][1]
                self.user.pos_y=TransPoint.List2[if_trans][2]
                self.state=GameState.LOADING
                return

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.state=GameState.EXIT
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.state=GameState.EXIT
                        return
                    
                if event.type== pygame.KEYDOWN:
                    player_move=-1
                    if event.key==pygame.K_w:
                        player_move=0
                    elif event.key==pygame.K_a:
                        player_move=1
                    elif event.key==pygame.K_s:
                        player_move=2
                    elif event.key==pygame.K_d:
                        player_move=3
                    elif event.key==pygame.K_1:
                        if(self.user.item_number==0):
                            self.user.item_number=-1
                        else:
                            self.user.item_number=0
                        self.user.last_item_number=0
                        player_move=4
                    elif event.key==pygame.K_2:
                        if(self.user.item_number==1):
                            self.user.item_number=-1
                        else:
                            self.user.item_number=1
                        self.user.last_item_number=1
                        player_move=4
                    elif event.key==pygame.K_3:
                        if(self.user.item_number==2):
                            self.user.item_number=-1
                        else:
                            self.user.item_number=2
                        self.user.last_item_number=2
                        player_move=4
                    elif event.key==pygame.K_r:
                        if(self.user.item_number!=-1):
                            self.user.rotate_item(self.user.item_number)
                    elif event.key==pygame.K_4:
                         print(self.user.pos_x,self.user.pos_y)
                    elif event.key==pygame.K_f:
                        self.user.laying_pos_x=self.user.pos_x
                        self.user.laying_pos_y=self.user.pos_y
                        if self.user.item_number!=-1:
                            if self.user.inventory.item[self.user.item_number].flag:
                                self.user.laying_pos_x,self.user.laying_pos_y=laying_pos_calc(self.user.pos_x,self.user.pos_y,self.user.inventory.item[self.user.item_number],self.mmap)
                        self.state=GameState.LAYING
                    elif event.key==pygame.K_e:
                        test=[self.mapid,self.user.pos_x+1,self.user.pos_y]
                        for i in range(NPCSetting.number):
                            if(NPCSetting.locate[i][0]==test[0] and NPCSetting.locate[i][1]==test[1] and NPCSetting.locate[i][2]==test[2]):
                                self.Taking_to=i
                                self.state=GameState.TALKING
                                return
                    elif event.key==pygame.K_q:
                        if(self.user.item_number!=-1):
                            self.user.inventory.item[self.user.item_number].flag=0
                    self.user.update_direction(player_move)
                    if move_legal(player_move,self.user,self.mmap)==1:
                        self.user.pos_x,self.user.pos_y=wasd_move(self.user.pos_x,self.user.pos_y,player_move)
                        

        elif self.state==GameState.LOADING:
            time.sleep(0.05)
            self.state=GameState.PLAY
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.state=GameState.EXIT
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.state=GameState.EXIT
                        return           


        elif self.state==GameState.LAYING:
            
            layer_top,layer_left,user_top,user_left=self.mmap.calc_topleft(self.user)
            self.screen.blit(self.mmap.map_image_layer,(layer_left,layer_top))
            
            for i in range(NPCSetting.number):
                if(NPCSetting.locate[i][0]==self.mapid):
                    NPCs.List[i].draw(self.screen,layer_top,layer_left)

            if(self.user.item_number!=-1):
                if(self.user.inventory.item[self.user.item_number].flag):
                    self.screen.blit(self.user.inventory.item[self.user.item_number].layer,(layer_left+self.user.laying_pos_x*BrickSetting.brick_len,layer_top+self.user.laying_pos_y*BrickSetting.brick_len))
            
            self.screen.blit(self.user.layer,(user_top,user_left))
            self.user.inventory.draw_inventory(self.user.item_number,self.screen)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.state=GameState.EXIT
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.state=GameState.EXIT
                        return
                if event.type== pygame.KEYDOWN:
                    laying_move=-1
                    if event.key==pygame.K_w:
                        laying_move=0
                    elif event.key==pygame.K_a:
                        laying_move=1
                    elif event.key==pygame.K_s:
                        laying_move=2
                    elif event.key==pygame.K_d:
                        laying_move=3
                    elif event.key==pygame.K_1:
                        self.user.item_number=0
                        self.user.last_item_number=0
                        self.user.laying_pos_x,self.user.laying_pos_y=laying_pos_calc(self.user.pos_x,self.user.pos_y,self.user.inventory.item[self.user.item_number],self.mmap)
                        laying_move=4
                    elif event.key==pygame.K_2:
                        self.user.item_number=1
                        self.user.last_item_number=1
                        self.user.laying_pos_x,self.user.laying_pos_y=laying_pos_calc(self.user.pos_x,self.user.pos_y,self.user.inventory.item[self.user.item_number],self.mmap)
                        laying_move=4
                    elif event.key==pygame.K_3:
                        self.user.item_number=2
                        self.user.last_item_number=2
                        self.user.laying_pos_x,self.user.laying_pos_y=laying_pos_calc(self.user.pos_x,self.user.pos_y,self.user.inventory.item[self.user.item_number],self.mmap)
                        laying_move=4
                    elif event.key==pygame.K_e:
                        if self.user.item_number!=-1:
                            if(self.user.inventory.item[self.user.item_number].flag):
                                lay_item=self.user.inventory.item[self.user.item_number]
                                laying_flag=1
                                for i in range(lay_item.rows):
                                    for j in range(lay_item.cols):
                                        map_brick=self.mmap.matrix[self.user.laying_pos_y+i][self.user.laying_pos_x+j]
                                        item_brick=lay_item.matrix[i][j]
                                        if(item_brick!=-1):
                                            if(BrickSetting.adding[map_brick][item_brick]==-1):
                                                laying_flag=0
                                if(laying_flag):
                                    
                                    for i in range(lay_item.rows):
                                        for j in range(lay_item.cols):
                                            map_brick=self.mmap.matrix[self.user.laying_pos_y+i][self.user.laying_pos_x+j]
                                            item_brick=lay_item.matrix[i][j]
                                            if(item_brick!=-1):
                                                self.mmap.matrix[self.user.laying_pos_y+i][self.user.laying_pos_x+j]=BrickSetting.adding[map_brick][item_brick]
                                    self.mmap.update(Bricks.List)
                                    self.user.inventory.item[self.user.item_number].flag=0
                    
                        laying_move=6
                    elif event.key==pygame.K_r:
                        if(self.user.item_number!=-1):
                            self.user.rotate_item(self.user.item_number)
                            laying_move=5
                    elif event.key==pygame.K_f:
                        self.state=GameState.PLAY
                        return

                    if self.user.item_number!=-1:
                        if laying_move<4 and laying_move>=0:
                            self.user.laying_pos_x,self.user.laying_pos_y=wasd_move(self.user.laying_pos_x,self.user.laying_pos_y,laying_move)
                    self.user.laying_pos_x,self.user.laying_pos_y=laying_pos_calc(self.user.laying_pos_x,self.user.laying_pos_y,self.user.inventory.item[self.user.item_number],self.mmap)


        elif self.state==GameState.TALKING:
            layer_top,layer_left,user_top,user_left=self.mmap.calc_topleft(self.user)
            self.screen.blit(self.mmap.map_image_layer,(layer_left,layer_top))
            self.screen.blit(self.user.layer,(user_top,user_left))
            self.user.inventory.draw_inventory(self.user.item_number,self.screen)
            
            for i in range(NPCSetting.number):
                if(NPCSetting.locate[i][0]==self.mapid):
                    NPCs.List[i].draw(self.screen,layer_top,layer_left)


            game_agent = GameLLMAgent()
            WHITE = (255, 255, 255)
            BLACK = (0, 0, 0)
            LIGHT_GRAY = (200, 200, 200)
            RED = (200, 0, 0)
            DARK_RED = (150, 0, 0)
            BLUE = (0, 100, 200)
            # Set up font
            font = pygame.font.Font(None, 24)

            # Input box settings
            input_box_rect = pygame.Rect(200, 400, 400, 50)
            input_text = ""  # To store user input
            active = False   # Whether the input box is active

            # Button settings
            button_rect = pygame.Rect(620, 400, 100, 50)
            button_text = "Close"

            # Valid characters
            valid_characters = string.ascii_letters + string.digits + string.punctuation + " "

            response_text=""
            if self.Taking_to==0:
                # Main loop
                clock = pygame.time.Clock()
                running = True
                if_response=0
                while running:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            running = False

                        # Handle mouse clicks
                        elif event.type == pygame.MOUSEBUTTONDOWN:
                            # Check if the input box is clicked
                            if input_box_rect.collidepoint(event.pos):
                                active = True
                            else:
                                active = False

                            # Check if the button is clicked
                            if button_rect.collidepoint(event.pos):
                            
                                self.state=GameState.PLAY
                                input_text = ""  # Clear the input text
                                active = False   # Deactivate input box
                                RUNNING=False
                                return
                        # Handle key presses
                        elif event.type == pygame.KEYDOWN and active:
                            if event.key == pygame.K_RETURN:
                                response_text = game_agent.chat_with_player(input_text)
                                if_response=1
                                input_text = ""  # Clear input on Enter
                            elif event.key == pygame.K_BACKSPACE:
                                input_text = input_text[:-1]  # Remove last character
                            else:
                                # Add valid characters to the input text
                                if event.unicode in valid_characters:
                                    input_text += event.unicode
                
                    layer_top,layer_left,user_top,user_left=self.mmap.calc_topleft(self.user)
                    self.screen.blit(self.mmap.map_image_layer,(layer_left,layer_top))
                    self.screen.blit(self.user.layer,(user_top,user_left))
                    self.user.inventory.draw_inventory(self.user.item_number,self.screen)                
                    for i in range(NPCSetting.number):
                        if(NPCSetting.locate[i][0]==self.mapid):
                            NPCs.List[i].draw(self.screen,layer_top,layer_left)
                    # Draw the input box
                    box_color = LIGHT_GRAY if active else WHITE  # Change color when active
                    pygame.draw.rect(self.screen, box_color, input_box_rect)
                    pygame.draw.rect(self.screen, BLACK, input_box_rect, 2)  # Black border

                    # Render and display the input text
                    text_surface = font.render(input_text, True, BLACK)
                    self.screen.blit(text_surface, (input_box_rect.x + 10, input_box_rect.y + 10))
                    if if_response:
                        wrapped_lines = wrap_text(response_text, font, 600)  # Max width is 600
                        for i, line in enumerate(wrapped_lines):
                            line_surface = font.render(line, True, WHITE)
                            line_rect = line_surface.get_rect(topleft=(100, 50 + i * 30))  # Adjust line spacing
                            pygame.draw.rect(self.screen, BLUE, line_rect)  # Draw background rectangle
                            self.screen.blit(line_surface, line_rect)  # Draw the text over the background
                    # Draw the button
                    pygame.draw.rect(self.screen, RED, button_rect)
                    pygame.draw.rect(self.screen, DARK_RED, button_rect, 2)  # Button border
                    button_text_surface = font.render(button_text, True, WHITE)
                    button_text_rect = button_text_surface.get_rect(center=button_rect.center)
                    self.screen.blit(button_text_surface, button_text_rect)

                    # Update the display
                    pygame.display.flip()
                    clock.tick(30)
            elif self.Taking_to==2:
                if(self.user.sword==0):
                    
                    response_text="The sword lies broken in the corner, rusted and weathered, as if abandoned by both time and the ravages of war. Once sharp and deadly, its blade is now split in two, exuding an air of solemn silence. It is said that if one can restore it, they shall once again wield the power that once made enemies tremble. Only those brave enough to face both loss and ruin can breathe life back into this weapon, reclaiming its former glory and awakening the bloodshed and triumph it once embodied."
                    wrapped_lines = wrap_text(response_text, font, 600)  # Max width is 600
                    for i, line in enumerate(wrapped_lines):
                        line_surface = font.render(line, True, WHITE)
                        line_rect = line_surface.get_rect(topleft=(100, 50 + i * 30))  # Adjust line spacing
                        pygame.draw.rect(self.screen, BLUE, line_rect)  # Draw background rectangle
                        self.screen.blit(line_surface, line_rect)
                    time.sleep(2)
                    self.user.inventory.item[0]=Item([[17,-1],[17,17],[17,-1]])
                    self.user.inventory.item[1]=Item([[16,16],[19,-1]])
                    self.user.inventory.item[2]=Item([[17],[19]])
                    self.user.inventory.item[0].flag=1
                    self.user.inventory.item[1].flag=1
                    self.user.inventory.item[2].flag=1
                    self.state=GameState.PLAY
                else:
                    self.state=GameState.PLAY
            elif self.Taking_to==1:
                t=ask_businessman()
                if t==1:
                    self.user.inventory.item[0]=Item([[16,16]])
                if t==2:
                    self.user.inventory.item[0]=Item([[17,17]])
                self.state=GameState.PLAY
            elif self.Taking_to==3:
                self.user.win=self.user.sword
                self.state=GameState.ENDING
                    
        elif self.state==GameState.ENDING:
            if self.user.win:
                EndingSetting.victory.Draw_image(self.background_layer,0,0,800,600)
            else:
                EndingSetting.defeat.Draw_image(self.background_layer,0,0,800,600)
            self.screen.blit(self.background_layer, (0, 0))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.state=GameState.EXIT
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.state=GameState.EXIT
                        return